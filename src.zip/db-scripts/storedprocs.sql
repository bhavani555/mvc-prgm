USE `Central_Library`;

DELIMITER //

CREATE PROCEDURE GetUserByEmailAndPassword
(IN email varchar(100), IN password varchar(100))
BEGIN 
	
	SELECT * FROM User u WHERE u.email = email AND u.password = password;
 
END //

CREATE PROCEDURE GetMemberbooksByIssueid
(IN id int (11))
BEGIN
	SELECT u.name,b.bookname,i.dateofissue,i.returndate
	FROM User u
	INNER JOIN issue i
	INNER JOIN books b
	on u.id=i.memberid && i.bid=b.id 
	where i.memberid=id;
END // 

CREATE PROCEDURE Getlibrariandetail
(IN id int(11))
BEGIN
	SELECT u.name,u.email,u.mobilenumber,u.dateofbirth
	FROM User u
	INNER JOIN issue i
	WHERE u.id=i.id && i.libid=id;
END //

CREATE PROCEDURE GetmembersByissueid
(IN id int(11))
BEGIN
	SELECT u.id,u.name,u.email,i.dateofissue,i.returndate
	FROM User u
	INNER JOIN issue i
	WHERE u.id=i.id && u.id=id;
END //

CREATE PROCEDURE GetBooksnameBycatagorynameAndId
(IN catagoryname varchar(45), IN id int(255))
BEGIN
 SELECT b.bookname,c.catagoryname
 FROM books b
 INNER JOIN catagories c
 WHERE b.id=c.id && c.catagoryname = catagoryname && c.bookid = id;
END // 

CREATE PROCEDURE GetLibrarianByRoleid
	(IN id int(11))
BEGIN 
	SELECT u.name,u.password,u.mobilenumber,u.dateofbirth,u.email FROM User u WHERE u.id =id;
END //

CREATE PROCEDURE Memberbook
(IN id int(11))
BEGIN
	SELECT u.name,b.bookname,i.dateofissue,i.returndate 
	FROM User u 
	INNER JOIN books b 
	INNER JOIN issue i 
	WHERE b.id=i.bid 
	AND u.id=i.memberid && u.id=id;

END //

CREATE PROCEDURE NewMemberCreate
(IN name varchar(45),IN password varchar(45),
 IN mobilenumber varchar(45),
 IN dateofbirth date,IN email varchar(45))
BEGIN
 
INSERT INTO `User`(`name`,`password`,`mobilenumber`,`dateofbirth`,`email`) VALUES
	(name,password,mobilenumber,dateofbirth, email);

END //


DELIMITER ;



