Login page:
 SELECT u.name, u.email, u.password 
 FROM users u
 where u.id=id;
 
 Bookname and catagory:
 select b.id,b.bookname,c.catagoryname from books b left join catagories c on b.id=c.id;

members Book details:
select u.id,u.name,b.bookname,i.dateofissue,i.returndate from users u inner join issue i inner join books b on u.id=i.memberid && b.id=i.bid;

select i.memberid,b.id,b.bookname from issue i right join books b on b.id=i.bid;

Librarian details:
select u.id,u.name from users u left join issue i on i.libid=u.id;

select b.id,b.bookname,i.dateofissue,i.returndate from issue i right join books b on b.id=i.bid where i.bid is null;

select b.id,b.bookname,i.dateofissue,i.returndate from issue i right join books b on b.id=i.bid where b.id is null;

select u.id,u.name,i.bid,i.dateofissue,i.returndate from users u right join issue i on i.libid=u.id;




SELECT u.name,b.bookname,i.dateofissue,i.returndate 
FROM User u 
INNER JOIN books b 
INNER JOIN issue i 
WHERE b.id=i.bid 
AND u.id=i.memberid;


