USE `Central_Library`;

INSERT INTO `roles`(`id`,`rolename`) VALUES
(1,'Librarian'),
(2,'Member');

INSERT INTO `User`(`id`,`name`,`password`,`mobilenumber`,`dateofbirth`,`email`,`roleid`) VALUES
(1,'John','asha','946738257','2008-05-06','john@gmail.com',1),
(2,'Suresh','anusha','946738321','2008-01-02','suresh@gmail.com',1),
(3,'Sathish','keerthi','9467382147','2008-01-04','sathish@gmail.com',1),
(4,'Ritesh','gggg','9467382569','2008-01-02','ritesh@gmail.com',1),
(5,'veeresh','clock','946738336','2008-01-03','veeresh@gmail.com',1),
(6,'Ramesh','ssss','946738201','2005-05-08','ramesh@instituite.com',2),
(7,'Rohan','uuuu','946738202','2005-04-09','suresh@instituite.com',2),
(8,'Ganesh','tttt','946738204','2005-05-09','jignesh@instituite.com',2),
(9,'Karthik','kkkk','946738205','2005-07-08','ritesh@instituite.com',2),
(10,'Kamlesh','hhhh','946738255','2005-05-01','kamlesh@instituite.com',2);

INSERT INTO books(`id`, `bookname`) VALUES
(1,"Brave new world"),
(2,"Origin of species"),
(3,"Time sports"),
(4,"Inventions and Inventors"),
(5,"Believe in urself");

INSERT INTO `catagories`(`id`,`catagoryname`,`bookid`) VALUES
(1,'Fiction',1),
(2,'Nonfiction',2),
(3,'sports',3),
(4,'Novel',4),
(5,'Biography',5);

INSERT INTO `issue`(`id`,`memberid`,`libid`,`bid`,`dateofissue`,`returndate`) VALUES
(1,6,1,1,'2018-05-08 10:25:22','2015-05-10 10:25:12'),
(2,6,4,4,'2018-01-03 10:25:22','2018-04-07 10:15:22'),
(3,7,3,3,'2018-10-17 10:25:22','2018-10-20 10:15:22'),
(4,8,2,4,'2018-10-17 10:25:22','2018-10-20 10:15:22');




