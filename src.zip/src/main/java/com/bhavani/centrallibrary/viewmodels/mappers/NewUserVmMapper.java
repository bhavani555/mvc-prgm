package com.bhavani.centrallibrary.viewmodels.mappers;

import java.sql.Date;

import com.bhavani.centrallibrary.viewmodels.NewUserVm;

public class NewUserVmMapper {
	public static NewUserVm toVm(String name,String password,String mobilenumber, Date dateofbirth,String email) {
		// TODO Auto-generated method stub
		
		NewUserVm newUserVm =new NewUserVm();
		newUserVm.setName(name);
		newUserVm.setPassword(password);
		newUserVm.setMobilenumber(mobilenumber);
		newUserVm.setDateofbirth(dateofbirth);
		newUserVm.setEmail(email);
		
		
		return newUserVm;
	}

}

