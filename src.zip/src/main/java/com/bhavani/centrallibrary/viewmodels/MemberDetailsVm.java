package com.bhavani.centrallibrary.viewmodels;

import java.sql.Date;
import java.util.List;


public class MemberDetailsVm {
	
public List<Members> members;	
	
	public List<Members> getMembers() {
		return members;
	}

	public void setCourses(List<Members> members) {
		this.members = members;
	}
	
	
	public class Members {
		
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	private String bookname;
	private Date dateofissue;
	private Date returndate;
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public Date getDateofissue() {
		return dateofissue;
	}
	public void setDateofissue(Date dateofissue) {
		this.dateofissue = dateofissue;
	}
	public Date getReturndate() {
		return returndate;
	}
	public void setReturndate(Date returndate) {
		this.returndate = returndate;
	}
}
}
