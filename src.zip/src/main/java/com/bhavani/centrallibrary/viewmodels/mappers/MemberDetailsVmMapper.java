package com.bhavani.centrallibrary.viewmodels.mappers;

import java.util.ArrayList;
import java.util.List;

import com.bhavani.centrallibrary.datamodels.Member;
import com.bhavani.centrallibrary.viewmodels.MemberDetailsVm;
import com.bhavani.centrallibrary.viewmodels.MemberDetailsVm.Members;


public class MemberDetailsVmMapper {
	public static MemberDetailsVm toVm(List<Member> members)
	{
		MemberDetailsVm memberDetailsVm = new MemberDetailsVm();
		List<MemberDetailsVm.Members> memberDetailsVmList=new ArrayList<MemberDetailsVm.Members>();
		for (Member member : members) {
			
	
			MemberDetailsVm.Members memberDetails = memberDetailsVm.new Members();
			memberDetails.setName(member.getName());
			memberDetails.setBookname(member.getBookname());
			memberDetails.setDateofissue(member.getDateofissue());
			memberDetails.setReturndate(member.getReturndate());
			memberDetailsVmList.add(memberDetails);
		}
		memberDetailsVm.setCourses(memberDetailsVmList);
		
		return memberDetailsVm;
	}
}