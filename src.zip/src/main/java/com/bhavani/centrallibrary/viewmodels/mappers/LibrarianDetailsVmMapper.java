package com.bhavani.centrallibrary.viewmodels.mappers;

import com.bhavani.centrallibrary.datamodels.Librarian;
import com.bhavani.centrallibrary.viewmodels.LibrarianDetailsVm;

public class LibrarianDetailsVmMapper {
	public static LibrarianDetailsVm toVm(Librarian librarian)
	{
		LibrarianDetailsVm librarianDetailsVm = new LibrarianDetailsVm();
	
	
		librarianDetailsVm.setName(librarian.getName());
		librarianDetailsVm.setPassword(librarian.getPassword());
		librarianDetailsVm.setMobilenumber(librarian.getMobilenumber());
		librarianDetailsVm.setDateofbirth(librarian.getDateofbirth());
		librarianDetailsVm.setEmail(librarian.getEmail());		
		
		return librarianDetailsVm;
	}
}
