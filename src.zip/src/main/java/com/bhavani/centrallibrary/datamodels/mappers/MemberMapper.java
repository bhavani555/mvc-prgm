package com.bhavani.centrallibrary.datamodels.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bhavani.centrallibrary.datamodels.Member;



public class MemberMapper implements RowMapper<Member> {
 
	 
			@Override
			public Member mapRow(ResultSet rs, int rowNum) throws SQLException {

				Member member = new Member();
				member.setName(rs.getString("name"));
				member.setBookname(rs.getString("bookname"));
				member.setDateofissue(rs.getDate("dateofissue"));
				member.setReturndate(rs.getDate("returndate"));
				
				
				return member;
}
}
