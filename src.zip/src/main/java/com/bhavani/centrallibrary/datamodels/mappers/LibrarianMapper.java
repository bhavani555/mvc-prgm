package com.bhavani.centrallibrary.datamodels.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bhavani.centrallibrary.datamodels.Librarian;


public class LibrarianMapper implements RowMapper<Librarian> {

	@Override
	public Librarian mapRow(ResultSet rs, int rowNum) throws SQLException {

		Librarian librarian = new Librarian();
	  

		librarian.setName(rs.getString("name"));
		librarian.setPassword(rs.getString("password"));
		librarian.setMobilenumber(rs.getString("mobilenumber"));
		librarian.setDateofbirth(rs.getDate("dateofbirth"));
		librarian.setEmail(rs.getString("email"));
		
		
		return librarian;
	}
}