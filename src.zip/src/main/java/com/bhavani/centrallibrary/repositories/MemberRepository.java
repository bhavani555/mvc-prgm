package com.bhavani.centrallibrary.repositories;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bhavani.centrallibrary.datamodels.Member;
import com.bhavani.centrallibrary.datamodels.mappers.MemberMapper;


@Repository
public class MemberRepository {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<Member> Memberbook(int id) {
		List<Member> member= jdbcTemplate.query("CALL Memberbook(?)",
							new Object[] { id },
				            new MemberMapper());
		
		return member;
		
}
}
