package com.bhavani.centrallibrary.repositories;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bhavani.centrallibrary.datamodels.Librarian;
import com.bhavani.centrallibrary.datamodels.mappers.LibrarianMapper;
import com.bhavani.centrallibrary.repositories.LibrarianRepository;

@Repository
public class LibrarianRepository {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public Librarian GetLibrarianByRoleid(int id)
	{
		Librarian librarian = jdbcTemplate.queryForObject("CALL GetLibrarianByRoleid(?)", 
														new Object[] { id }, 
														new LibrarianMapper());
		
		return librarian;
	}
}
