package com.bhavani.centrallibrary.repositories;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bhavani.centrallibrary.datamodels.Member;
import com.bhavani.centrallibrary.datamodels.User;
import com.bhavani.centrallibrary.datamodels.mappers.UserMapper;


@Repository
public class UserRepository {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<User> GetByRole(long roleId) {

		List<User> user = jdbcTemplate.query("CALL GetUsersByRoleId(?)", new Object[] { roleId }, new UserMapper());

		return user;
	}

	public User GetByUserNameAndPassword(String email, String password) {

		User user = null;

		try {

			user = jdbcTemplate.queryForObject("CALL GetUserByEmailAndPassword(?, ?)",
					new Object[] { email, password }, new UserMapper());

		} catch (EmptyResultDataAccessException ex) {
			
			return null;
		}

		return user;

		/*
		 * SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
		 * .withProcedureName("GetUserByEmailAndPassword")
		 * .withoutProcedureColumnMetaDataAccess() . declareParameters( new
		 * SqlParameter("email", Types.VARCHAR), new SqlParameter("password",
		 * Types.VARCHAR));
		 * 
		 * Map<String, Object> execute = call.execute(new MapSqlParameterSource("email",
		 * email), new MapSqlParameterSource("password", password));
		 * 
		 * String email1 = (String)execute.get("email");
		 */
	}
	public void getCreateNewUser(String name,String password,String mobilenumber,Date dateofbirth,String email) {
		 jdbcTemplate.update("CALL NewMemberCreate(?,?,?,?,?)",
				  name,password,mobilenumber,dateofbirth,email);
		
		
		
	}
	
}


