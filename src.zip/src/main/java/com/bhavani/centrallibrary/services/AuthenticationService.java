package com.bhavani.centrallibrary.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bhavani.centrallibrary.datamodels.User;
import com.bhavani.centrallibrary.repositories.UserRepository;


@Service
public class AuthenticationService {
	@Autowired
	private UserRepository userRepository;

	public User Authenticate(String username, String password)
	{
		User user = userRepository.GetByUserNameAndPassword(username, password);
		
		if(user!=null)
		{
			return user;
		}
		
		return null;
	}	

}

