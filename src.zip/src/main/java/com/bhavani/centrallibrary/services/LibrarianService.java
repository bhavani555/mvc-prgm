package com.bhavani.centrallibrary.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bhavani.centrallibrary.datamodels.Librarian;
import com.bhavani.centrallibrary.repositories.LibrarianRepository;



@Service
public class LibrarianService {
	@Autowired
	private LibrarianRepository librarianRepository;
	
	public Librarian GetLibrarianByRoleid(int id) {
	
	
		return librarianRepository.GetLibrarianByRoleid(id);
	}	
}
