package com.bhavani.centrallibrary.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bhavani.centrallibrary.datamodels.User;
import com.bhavani.centrallibrary.repositories.UserRepository;
import com.bhavani.centrallibrary.viewmodels.NewUserVm;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	public List<User> GetByRole(long id) {
		return userRepository.GetByRole(id);

	}

	public void getCreateNewUser(NewUserVm newuserVm) {

		userRepository.getCreateNewUser(newuserVm.getName(), newuserVm.getPassword(), newuserVm.getMobilenumber(),
				newuserVm.getDateofbirth(), newuserVm.getEmail());
	}

}
