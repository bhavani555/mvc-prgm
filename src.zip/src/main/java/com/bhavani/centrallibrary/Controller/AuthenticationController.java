package com.bhavani.centrallibrary.Controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.bhavani.centrallibrary.datamodels.User;
import com.bhavani.centrallibrary.services.AuthenticationService;
import com.bhavani.centrallibrary.viewmodels.LoginVm;

@Controller
public class AuthenticationController {

	@Autowired
	private AuthenticationService authenticationService;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView login() {

		ModelAndView mv = new ModelAndView();

		LoginVm loginVm = new LoginVm();
		loginVm.setError(null);
		mv.addObject("loginVm", loginVm);

		mv.setViewName("login");

		return mv;
		// return "login";
	}

	/*@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(LoginVm loginVm, HttpSession session, HttpServletResponse servletResponse) {

		ModelAndView mv = new ModelAndView();

		boolean authenticated = authenticationService.Authenticate(loginVm.getUsername(), loginVm.getPassword());

		if (authenticated) {

			session.setAttribute("username", loginVm.getUsername());
			session.setAttribute("id", loginVm.getPassword());
			session.setAttribute("authenticated", true);

			servletResponse.addCookie(new Cookie("COOKIENAME", "Thecookiesgit"));

			mv.setViewName("redirect:/librariandetails");
			return mv;
			// return "redirect:/course";
		}

		loginVm.setError("Wrong Usernameand Password Combination");
		mv.addObject("loginVm", loginVm);

		mv.setViewName("login");
		return mv;
	}*/
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(LoginVm loginVm, HttpSession session, HttpServletResponse servletResponse) {

		ModelAndView mv = new ModelAndView();

		User user = authenticationService.Authenticate(loginVm.getUsername(), loginVm.getPassword());

		if (user != null) {

			session.setAttribute("name", user.getName());
			session.setAttribute("id", user.getId());
			session.setAttribute("authenticated", true);

			mv.setViewName("redirect:/librariandetails" + user.getId());
			return mv;
			// return "redirect:/course";
		}

		loginVm.setError("Wrong Usernameand Password Combination");
		mv.addObject("loginVm", loginVm);

		mv.setViewName("login");
		return mv;
	}
	

	@RequestMapping(value = "/librariandetails", method = RequestMethod.GET)
	public String logout(HttpSession session, HttpServletResponse servletResponse) {

		return "librariandetails";

	}

}
