package com.bhavani.centrallibrary.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.bhavani.centrallibrary.datamodels.Librarian;
import com.bhavani.centrallibrary.datamodels.Member;
import com.bhavani.centrallibrary.services.LibrarianService;
import com.bhavani.centrallibrary.services.MemberService;
import com.bhavani.centrallibrary.services.UserService;
import com.bhavani.centrallibrary.viewmodels.LibrarianDetailsVm;
import com.bhavani.centrallibrary.viewmodels.MemberDetailsVm;
import com.bhavani.centrallibrary.viewmodels.NewUserVm;
import com.bhavani.centrallibrary.viewmodels.mappers.LibrarianDetailsVmMapper;
import com.bhavani.centrallibrary.viewmodels.mappers.MemberDetailsVmMapper;

@Controller
public class LibraryController {
	@Autowired
	private UserService userService;
	@Autowired
	private LibrarianService librarianService;
	@Autowired
	private MemberService memberService;
	
	@RequestMapping(value = "/createnewmember",method = RequestMethod.GET)
	public ModelAndView NewUser() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("createnewmember");
		return mv;
	}

	@RequestMapping(value = "/createnewmember", method = RequestMethod.POST)
	public ModelAndView NewUser(NewUserVm newuserVm) {
		ModelAndView mv = new ModelAndView();
		userService.getCreateNewUser(newuserVm);
		mv.setViewName("librarian");

		return mv;
	}

	
	@RequestMapping(value = "/user", method = RequestMethod.POST)
	public ModelAndView ShowDetails() {
		ModelAndView mv = new ModelAndView();
		
		mv.setViewName("login");

		return mv;
	}
	
	
	
	
	
	

	@RequestMapping(value = "/MemberDashboard/{id}", method = RequestMethod.GET)
	public ModelAndView course(@PathVariable(value = "id") int id ) {



	ModelAndView mv = new ModelAndView();

	List<Member> members =memberService.Memberbook(id);

	MemberDetailsVm memberDetailsVm = MemberDetailsVmMapper.toVm(members);	
	mv.addObject("memberDetailsVm", memberDetailsVm);

	mv.setViewName("MemberDashboard");

	return mv;
	}

	/*@RequestMapping(value = "/dashboard/{appointmentid}", method = RequestMethod.GET)
	public ModelAndView history(@PathVariable(value = "appointmentid") long appointmentid) {
	*/

	@RequestMapping(value = "/librariandetails/{id}", method = RequestMethod.GET)
	public ModelAndView librarian(@PathVariable(value = "id") int id) {

		ModelAndView mv = new ModelAndView();

		Librarian librarian = librarianService.GetLibrarianByRoleid(id);

		LibrarianDetailsVm librarianDetailsVm = LibrarianDetailsVmMapper.toVm(librarian);
		librarianDetailsVm.setId(id);
		mv.addObject("librarianDetails", librarianDetailsVm);

		mv.setViewName("librariandetails");

		return mv;
		
	}
	/*@RequestMapping(value = "/dashboard/{appointmentid}", method = RequestMethod.GET)
	public ModelAndView history(@PathVariable(value = "appointmentid") long appointmentid) {

		ModelAndView mv = new ModelAndView();

		HistoryInfo historyInfo = historyservice.GetAppointmentHisotryById(appointmentid);

		HistoryVm historyvm = HistoryVmMapper.toVm(historyInfo);
		historyvm.setAppointmentid(appointmentid);

		mv.addObject("history", historyvm);

		mv.setViewName("dashboard");

		return mv;
*/
	
	
}
